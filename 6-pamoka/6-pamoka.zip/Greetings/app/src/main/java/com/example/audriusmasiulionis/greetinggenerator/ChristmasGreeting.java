package com.example.audriusmasiulionis.greetinggenerator;

public class ChristmasGreeting {

    private String friendsName;
    private boolean isNewYearGreeting;
    private String extraText;

    public String getMessageBody() {

        // Implement the method
        return "Test";
    }
}
